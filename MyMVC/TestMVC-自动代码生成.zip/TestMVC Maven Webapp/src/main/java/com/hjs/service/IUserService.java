package com.hjs.service;

import com.hjs.pojo.User;  

public interface IUserService {  
    public User getUserById(int userId);  
}  
